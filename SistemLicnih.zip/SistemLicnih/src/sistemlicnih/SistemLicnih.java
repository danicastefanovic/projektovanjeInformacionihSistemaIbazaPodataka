/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemlicnih;

/**
 *
 * @author Danica
 */
public class SistemLicnih {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      //new Home().setVisible(true);
     // Registracija reg=new Registracija();
    //  reg.show();
   // Login lw=new Login();
    //lw.show();
   // Drzava dw=new Drzava();
   // dw.show();
   Mesto mw=new Mesto();
   mw.show();
    }
    
}
