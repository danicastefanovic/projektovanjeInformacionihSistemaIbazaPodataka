/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemlicnih;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;

/**
 *
 * @author Danica
 */
public class MySQLConnector {
    Connection conn;
    public Connection getConn(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
        conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/licne","root","sveska55");
        JOptionPane.showMessageDialog(null,"Baza podataka " + "je uspešno povezana!");
        return conn;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error in connection" + e);
        }
        return conn;
    }
}
